import java.util.Scanner;

public class AppCalculos {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            opcao = input.nextInt();

            switch (opcao) {
                case 1:
                    executarMatriz(input);
                    break;
                case 2:
                    executarEquacao(input);
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Escolha inválida!");
            }
        }

        input.close();
    }

    public static void exibirMenu() {
        System.out.println("\n====== ESCOLHA ======");
        System.out.println("1 - Digitar matriz");
        System.out.println("2 - Resolver equação");
        System.out.println("0 - Sair");
        System.out.print("Opção: ");
    }

    public static void executarMatriz(Scanner input) {
        int[][] m = new int[2][2];

        System.out.println("\nPreencha a matriz:");

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.print("Posição [" + i + "][" + j + "]: ");
                m[i][j] = input.nextInt();
            }
        }

        mostrarMatriz(m);
    }

    public static void mostrarMatriz(int[][] matriz) {
        System.out.println("\nMatriz resultante:");

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.printf("%4d", matriz[i][j]);
            }
            System.out.println();
        }
    }

    public static void executarEquacao(Scanner input) {
        System.out.println("\nEquação do 2º grau (ax² + bx + c)");

        double a = lerValor(input, "a");
        double b = lerValor(input, "b");
        double c = lerValor(input, "c");

        resolverEquacao(a, b, c);
    }

    public static double lerValor(Scanner input, String nome) {
        System.out.print("Informe " + nome + ": ");
        return input.nextDouble();
    }

    public static void resolverEquacao(double a, double b, double c) {
        double delta = Math.pow(b, 2) - 4 * a * c;

        System.out.println("Delta calculado: " + delta);

        if (delta < 0) {
            System.out.println("Sem raízes reais.");
            return;
        }

        double r1 = (-b + Math.sqrt(delta)) / (2 * a);
        double r2 = (-b - Math.sqrt(delta)) / (2 * a);

        System.out.printf("Raiz 1: %.2f\n", r1);
        System.out.printf("Raiz 2: %.2f\n", r2);
    }
}
